#pragma once

#include "Database.h"
#include "Table.h"
#include "Row.h"
#include "ColumnNames.h"
#include "RelationalAlgebra.h"
