void test_relational_algebra(int argc, const char** argv);

int main(int argc, const char** argv)
{
    test_relational_algebra(argc, argv);
}
